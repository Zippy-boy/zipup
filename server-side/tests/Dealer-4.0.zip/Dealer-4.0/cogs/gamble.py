import discord
from discord import Embed, Guild, app_commands
from discord.ext import commands
import sql
import asyncio
import random
from games import blackjack
import json


class colors():
    red = 0xFF0000
    green = 0x00FF00
    blue = 0x0000FF
    yellow = 0xFFFF00
    purple = 0xFF00FF
    cyan = 0x00FFFF
    white = 0xFFFFFF
    black = 0x000000
    gray = 0x808080
    orange = 0xFFA500
    pink = 0xFF69B4
    lime = 0x32CD32
    magenta = 0xFF00FF
    silver = 0xC0C0C0
    maroon = 0x800000
    gold = 0xFFD700


def create_ussr(user_id):
    if sql.get_user(user_id) is None:
        sql.create_user(user_id)
        return True


def check_loan(user_id):
    if sql.get_loan(user_id) != 0:
        if sql.get_loan(user_id) * 2 < sql.get_balance(
                user_id)[0] + sql.get_balance(user_id)[1]:
            sql.update_balance(
                user_id,
                sql.get_balance(user_id)[0] + sql.get_balance(user_id)[1], 0)
            sql.update_balance(
                user_id,
                sql.get_balance(user_id)[0] - sql.get_loan(user_id), 0)
            sql.update_loan(user_id, 0)
            return True
        else:
            return False
    return False

# make a function to check if the user has anogh money to bet


def check_player_money(user_id, bet):
    if sql.get_balance(user_id)[0] <= bet:
        return "not enough money"
    elif bet < 0:
        return "negative money"
    else:
        return False


blackjackCommands = blackjack.controlCommands()


class bj(discord.ui.View):
    def __init__(self, user, dealer, user_id, amout):
        super().__init__()
        self.value = None
        self.user = user
        self.dealer = dealer
        self.user_id = user_id
        self.amout = amout

    global CardData
    f = open("cardsEmojis.json")
    CardData = json.load(f)

    @discord.ui.button(label='Hit', style=discord.ButtonStyle.green)
    async def hit(self, interaction: discord.Interaction,
                  button: discord.ui.Button):

        if self.user_id != interaction.user.id:
            await interaction.response.send_message("This is not your game",
                                                    ephemeral=True)
            return

        dealerTotal = blackjackCommands.CalculateTotalValue(self.dealer)
        dealerMove = blackjackCommands.DealerMove(dealerTotal)

        card = blackjackCommands.MakeMove("Hit")
        if card["number"] == "A":
            if blackjackCommands.CalculateTotalValue(self.user) + 11 > 21:
                card["value"] = 1
            else:
                card["value"] = 11
        self.user.append(card)

        if dealerMove == "Hit":
            card = blackjackCommands.MakeMove(dealerMove)
            if card["number"] == "A":
                if dealerTotal + 11 > 21:
                    card["value"] = 1
                else:
                    card["value"] = 11

            self.dealer.append(card)

        if blackjackCommands.CalculateTotalValue(
                self.user) < 21 and blackjackCommands.CalculateTotalValue(
                    self.dealer) < 21:
            embed = Embed(
                title=f":moneybag: **{interaction.user.name}'s Blackjack** :moneybag:",
                description=f"You have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**"
            )

            embed.add_field(name="Your cards:",
                            value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                           for card in self.user]),
                            inline=False)

            await interaction.response.edit_message(embed=embed)

        else:
            dealerTotal = blackjackCommands.CalculateTotalValue(self.dealer)

            while blackjackCommands.CalculateTotalValue(self.dealer) < 21:

                dealerTotal = blackjackCommands.CalculateTotalValue(
                    self.dealer)
                dealerMove = blackjackCommands.DealerMove(dealerTotal)

                if dealerMove == "Hit":
                    card = blackjackCommands.MakeMove(dealerMove)
                    if card["number"] == "A":
                        if dealerTotal + 11 > 21:
                            card["value"] = 1
                        else:
                            card["value"] = 11
                    self.dealer.append(card)

                if dealerMove == "Stand":
                    break

            Won = blackjackCommands.CalculateWinner(self.dealer, self.user)
            if Won[0] == "Dealer":
                sql.update_balance(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] - self.amout,
                    sql.get_balance(interaction.user.id)[1])
            elif Won[0] == "User":
                sql.update_balance(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] + self.amout,
                    sql.get_balance(interaction.user.id)[1])
            else:
                pass

            for item in self.children:
                item.disabled = True

            if Won[0] == "Dealer":
                if Won[1] == "UserBust":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**You Went Bust!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.red
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)
                if Won[1] == "21":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**You lost! The Dealer Hit 21**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.red
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

                if Won[1] == "More":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**You lost!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.red
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

                if Won[1] == "Tie":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**Draw!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.orange
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

            else:
                if Won[1] == "DealerBust":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**The Dealer Went Bust!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.green
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

                if Won[1] == "21":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**You won! You Hit 21!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.green
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

                if Won[1] == "More":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**You won!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.green
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

                if Won[1] == "Tie":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**Draw!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.orange
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

                if Won[1] == "Both Bust":
                    embed = Embed(
                        title=f"**{interaction.user.name}'s Blackjack**",
                        description=f"**Draw! Both Bust!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                        color=colors.orange
                    )

                    embed.add_field(name="Your cards:",
                                    value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                                   for card in self.user]),
                                    inline=False)

            await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label='Stand', style=discord.ButtonStyle.red)
    async def stand(self, interaction: discord.Interaction,
                    button: discord.ui.Button):
        if self.user_id != interaction.user.id:
            await interaction.response.send_message("This is not your game",
                                                    ephemeral=True)
            return

        while blackjackCommands.CalculateTotalValue(self.dealer) < 21:

            dealerTotal = blackjackCommands.CalculateTotalValue(
                self.dealer)
            dealerMove = blackjackCommands.DealerMove(dealerTotal)

            if dealerMove == "Hit":
                card = blackjackCommands.MakeMove(dealerMove)
                if card["number"] == "A":
                    if dealerTotal + 11 > 21:
                        card["value"] = 1
                    else:
                        card["value"] = 11
                self.dealer.append(card)

            if dealerMove == "Stand":
                break

        Won = blackjackCommands.CalculateWinner(self.dealer, self.user)

        if Won[0] == "Dealer":
            sql.update_balance(
                interaction.user.id,
                sql.get_balance(interaction.user.id)[0] - self.amout,
                sql.get_balance(interaction.user.id)[1])
        elif Won[0] == "User":
            sql.update_balance(
                interaction.user.id,
                sql.get_balance(interaction.user.id)[0] + self.amout,
                sql.get_balance(interaction.user.id)[1])
        else:
            pass

        for item in self.children:
            item.disabled = True

        if Won[0] == "Dealer":
            if Won[1] == "UserBust":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**You Went Bust!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.red
                )

                embed.add_field(name="Your cards:",
                                value=[(CardData[str(card["suit"])+str(card["number"])])
                                       for card in self.user],
                                inline=False)
            if Won[1] == "21":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**You lost! The Dealer Hit 21**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.red
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

            if Won[1] == "More":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**You lost!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.red
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

            if Won[1] == "Tie":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**Draw!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.orange
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

        else:
            if Won[1] == "DealerBust":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**The Dealer Went Bust!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.green
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

            if Won[1] == "21":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**You won! You Hit 21!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.green
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

            if Won[1] == "More":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**You won!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.green
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

            if Won[1] == "Tie":
                embed = Embed(
                    title=f"**{interaction.user.name}'s Blackjack**",
                    description=f"**Draw!**\nYou have a total of: **{blackjackCommands.CalculateTotalValue(self.user)}**\nThe dealer has a total of: **{blackjackCommands.CalculateTotalValue(self.dealer)}**",
                    color=colors.orange
                )

                embed.add_field(name="Your cards:",
                                value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                               for card in self.user]),
                                inline=False)

        await interaction.response.edit_message(embed=embed, view=self)


class gamble(commands.Cog, name="gamble"):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="blackjack", description="Play blackjack")
    async def blackjack(self, interaction: discord.Interaction, amount: str):
        """ Account management """
        create_ussr(interaction.user.id)
        if amount.lower() == "all" or amount.lower() == "max":
            amout = sql.get_balance(interaction.user.id)[0]
        else:
            try:
                amount = int(amount)
            except:
                return await interaction.response.send_message(
                    "Invalid amount", ephemeral=True)

        if check_player_money(interaction.user.id,
                              amount) == "not enough money":
            return await interaction.response.send_message(
                "You don't have enough money", ephemeral=True)
        elif check_player_money(interaction.user.id,
                                amount) == "negative money":
            return await interaction.response.send_message(
                "You can't bet negative money", ephemeral=True)

        else:
            """Start game"""
            dealer = [
                blackjackCommands.GenerateCard(),
                blackjackCommands.GenerateCard()
            ]
            user = [
                blackjackCommands.GenerateCard(),
                blackjackCommands.GenerateCard()
            ]

            veiw = bj(user, dealer, interaction.user.id, amount)
            embed = Embed(
                title=f":moneybag: ** {interaction.user.name} Blackjack** :moneybag:",
                description=f"You have a total of **{blackjackCommands.CalculateTotalValue(user)}!**",
                color=colors.black)

            embed.add_field(name="Cards:",
                            inline=False,
                            value=''.join([(CardData[str(card["suit"])+str(card["number"])])
                                           for card in user]))

            await interaction.response.send_message(embed=embed, view=veiw)

    @ app_commands.command(name="flip", description="Flip a coin")
    async def flip(self, interaction: discord.Interaction, amount: str):
        create_ussr(interaction.user.id)
        if check_loan(interaction.user.id) == True:
            await interaction.response.send_message(
                "Your debt has been paid off!", ephemeral=True)
            return
        if amount == "all" or amount == "max":
            amount = 20
        else:
            try:
                amount = int(amount)
            except:
                await interaction.response.send_message("Invalid amount",
                                                        ephemeral=True)
        if amount > sql.get_balance(interaction.user.id)[0]:
            await interaction.response.send_message(
                "You don't have enough money", ephemeral=True)
        elif amount < 0:
            await interaction.response.send_message(
                "You can't bet negative money", ephemeral=True)
        elif amount > 20:
            await interaction.response.send_message(
                "You can't bet more than 100", ephemeral=True)
        else:
            import random

            if random.randint(0, 1) == 0:
                embed = Embed(
                    title=f":moneybag: Blackjack {interaction.user.name} :moneybag: ",
                    description=f"You flipped a **HEAD**\nYou won {amount} :dollar:",
                    color=colors.green,
                )
                await interaction.response.send_message(embed=embed)
                sql.update_user(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] + amount,
                    sql.get_balance(interaction.user.id)[1],
                    "",
                )
            else:
                embed = Embed(
                    title=f":moneybag: Blackjack {interaction.user.name} :moneybag: ",
                    description=f"You flipped a **TAIL**\nYou lost {amount} :dollar:",
                    color=colors.red,
                )
                await interaction.response.send_message(embed=embed)
                sql.update_user(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] - amount,
                    sql.get_balance(interaction.user.id)[1],
                    "",
                )

    @ app_commands.command(name="slots", description="Play slots")
    async def slots(self, interaction: discord.Interaction):
        create_ussr(interaction.user.id)
        if check_loan(interaction.user.id) == True:
            await interaction.response.send_message(
                "Your debt has been paid off!", ephemeral=True)
            return
        amount = 100
        if amount > sql.get_balance(interaction.user.id)[0]:
            await interaction.response.send_message(
                "You don't have enough money", ephemeral=True)
        else:
            slots = ["🍇", "🔔", "🍐", "🍒", "🍋", "🍉"]
            import random

            choice1 = random.choice(slots)
            choice2 = random.choice(slots)
            choice3 = random.choice(slots)

            embed = Embed(
                title=f":moneybag: Slots {interaction.user.name} :moneybag: ",
                description=f":white_circle:--:white_circle:--:white_circle:",
                color=colors.cyan,
            )
            await interaction.response.send_message(embed=embed)

            embed.description = f"-<a:Slots:1078759635751804938>-<a:Slots:1078759635751804938>-<a:Slots:1078759635751804938>-"
            await interaction.edit_original_response(embed=embed)

            await asyncio.sleep(1)

            embed.description = f"-{choice1}-<a:Slots:1078759635751804938>-<a:Slots:1078759635751804938>-"
            await interaction.edit_original_response(embed=embed)

            await asyncio.sleep(1)

            embed.description = f"-{choice1}-{choice2}-<a:Slots:1078759635751804938>-"
            await interaction.edit_original_response(embed=embed)

            await asyncio.sleep(1)

            embed.description = f"-{choice1}-{choice2}-{choice3}-"
            await interaction.edit_original_response(embed=embed)

            await asyncio.sleep(1)

            if choice1 == choice2 == choice3:
                embed = Embed(
                    title=f":moneybag: Slots {interaction.user.name} :moneybag: ",
                    description=f":dollar: You won jackpot 1000! :dollar:",
                    color=colors.gold,
                )
                await interaction.edit_original_response(embed=embed)
                sql.update_user(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] + 1000,
                    sql.get_balance(interaction.user.id)[1],
                    "",
                )

            elif choice1 == choice2 or choice2 == choice3:
                embed = Embed(
                    title=f":moneybag: Slots {interaction.user.name} :moneybag: ",
                    description=f":dollar: You won 100! :dollar:",
                    color=colors.green,
                )
                await interaction.edit_original_response(embed=embed)
                sql.update_user(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] + 100,
                    sql.get_balance(interaction.user.id)[1],
                    "",
                )

            elif choice1 == choice3:
                embed = Embed(
                    title=f":moneybag: Slots {interaction.user.name} :moneybag: ",
                    description=f":dollar: You won 250! :dollar:",
                    color=colors.green,
                )
                await interaction.edit_original_response(embed=embed)
                sql.update_user(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] + 250,
                    sql.get_balance(interaction.user.id)[1],
                    "",
                )
            else:
                embed = Embed(
                    title=f":moneybag: Slots {interaction.user.name} :moneybag: ",
                    description=f":dollar: You lost {amount}! :dollar:",
                    color=colors.red,
                )

                await interaction.edit_original_response(embed=embed)
                sql.update_user(
                    interaction.user.id,
                    sql.get_balance(interaction.user.id)[0] - amount,
                    sql.get_balance(interaction.user.id)[1],
                    "",
                )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(gamble(bot))
