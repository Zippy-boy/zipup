from code import interact
from logging import getLogRecordFactory
from math import e
import discord
from discord import Embed, Guild, app_commands
from discord.ext import commands
import sql


class colors():
    red = 0xFF0000
    green = 0x00FF00
    blue = 0x0000FF
    yellow = 0xFFFF00
    purple = 0xFF00FF
    cyan = 0x00FFFF
    white = 0xFFFFFF
    black = 0x000000
    gray = 0x808080
    orange = 0xFFA500
    pink = 0xFF69B4
    lime = 0x32CD32
    magenta = 0xFF00FF
    silver = 0xC0C0C0
    maroon = 0x800000


def create_ussr(user_id):
    if sql.get_user(user_id) is None:
        sql.create_user(user_id)
        return True


class account(commands.Cog, name="account"):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="info", description="Check your balance")
    async def info(self, interaction: discord.Integration, user: discord.User = None):
        if user is None:
            user_id = interaction.user.id
        else:
            user_id = user.id
        create_ussr(interaction.user.id)
        embed = Embed(
            title=f"@{interaction.user if user == None else user}'s Balance",
            description=f"**💵 Pocket**: {format(sql.get_balance(user_id)[0], ',d')}\n**💳 Bank**: {format(sql.get_balance(user_id)[1], ',d')}\n**💰 Total**: {format(sql.get_balance(user_id)[0] + sql.get_balance(user_id)[1], ',d')}",
            color=colors.cyan,
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="deposit", description="Deposit money into your bank")
    async def deposit(self, interaction: discord.Integration, amount: str):
        create_ussr(interaction.user.id)
        if amount == "all" or amount == "max":
            amount = sql.get_balance(interaction.user.id)[0]
        else:
            try:
                amount = int(amount)
            except:
                await interaction.response.send_message(
                    "Invalid amount", ephemeral=True
                )
        if amount > sql.get_balance(interaction.user.id)[0]:
            await interaction.response.send_message(
                "You don't have enough money", ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"Deposited {format(amount, ',d')} into your bank", ephemeral=False
            )
            sql.update_user(
                interaction.user.id,
                sql.get_balance(interaction.user.id)[0] - amount,
                sql.get_balance(interaction.user.id)[1] + amount,
                "",
            )

    @app_commands.command(name="withdraw", description="Withdraw money from your bank")
    async def withdraw(self, interaction: discord.Integration, amount: str):
        create_ussr(interaction.user.id)
        if amount == "all" or amount == "max":
            amount = sql.get_balance(interaction.user.id)[1]
        else:
            try:
                amount = int(amount)
            except:
                await interaction.response.send_message(
                    "Invalid amount", ephemeral=True
                )
        if amount > sql.get_balance(interaction.user.id)[1]:
            await interaction.response.send_message(
                "You don't have enough money", ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"Withdrew {format(amount, ',d')} from your bank", ephemeral=False
            )
            sql.update_user(
                interaction.user.id,
                sql.get_balance(interaction.user.id)[0] + amount,
                sql.get_balance(interaction.user.id)[1] - amount,
                "",
            )

    @app_commands.command(name="send", description="Send money to another user")
    async def send(
        self, interaction: discord.Integration, amount: str, user: discord.User
    ):
        create_ussr(interaction.user.id)
        if amount == "all" or amount == "max":
            amount = sql.get_balance(interaction.user.id)[0]
        else:
            try:
                amount = int(amount)
            except:
                await interaction.response.send_message(
                    "Invalid amount", ephemeral=True
                )
        if amount > sql.get_balance(interaction.user.id)[0]:
            await interaction.response.send_message(
                "You don't have enough money", ephemeral=True
            )
        elif amount < 0:
            await interaction.response.send_message(
                "You can't send negative money", ephemeral=True
            )

        else:
            await interaction.response.send_message(
                f"Sent {format(amount, ',d')} to {user}", ephemeral=False
            )
            sql.update_user(
                interaction.user.id,
                sql.get_balance(interaction.user.id)[0] - amount,
                sql.get_balance(interaction.user.id)[1],
                ""
            )
            sql.update_user(
                user.id,
                sql.get_balance(user.id)[0] + amount,
                sql.get_balance(user.id)[1],
                "",
            )

    @app_commands.command(name="loan", description="Get a loan from the bank")
    async def loan(self, interaction: discord.Integration):
        create_ussr(interaction.user.id)
        if sql.get_balance(interaction.user.id)[0] + sql.get_balance(interaction.user.id)[1] > 0:
            await interaction.response.send_message(
                "You already have money", ephemeral=True
            )
        else:
            await interaction.response.send_message(
                "You have been loaned 100 💵", ephemeral=False
            )
            sql.update_loan(interaction.user.id, 100)
            sql.update_balance(interaction.user.id, 100, 0)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(account(bot))
