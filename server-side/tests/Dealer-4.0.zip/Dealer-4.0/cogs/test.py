import discord
from discord import Guild, app_commands
from discord.ext import commands

TEST_GUILD = 676022602258448396

class test(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # @app_commands.command(
    #     name="test",
    #     description="Test command"
    # )
    # async def test(self, interaction: discord.Interaction, name: str, age: int,):
    #     await interaction.response.send_message("Hello " + name + str(age))
    
    @app_commands.command(
        name="ping",
        description="Response time of the bot"
    )
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message("Pong! " + str(round(self.bot.latency) * 1000), ephemeral=True)



async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(
        test(bot),
        guilds = [discord.Object(id=TEST_GUILD)]
    )