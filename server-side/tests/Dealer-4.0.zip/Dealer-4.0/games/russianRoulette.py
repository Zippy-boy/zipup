import random

def main():
    users = []
    while True:
        user = input("Enter User ('stop' to stop): ")
        if user == "stop":
            break
        users.append(user)
        
    print(users)
    victim = random.choice(users)
    victimIndex = user.index(victim)

main()