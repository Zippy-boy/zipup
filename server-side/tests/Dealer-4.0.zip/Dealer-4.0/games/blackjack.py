import random


class controlCommands():
    def __init__(self) -> None:
        self.cardDic = {
            "K": 10,  # King
            "Q": 10,  # Queen
            "J": 10,  # Jack
            "A": 11,  # Ace
        }

        # Suits
        self.suitDic = [
            "H",  # Hearts
            "C",  # Clubs
            "S",  # Spades
            "D",  # Diamonds
        ]

    def GenerateCard(self):

        randomCardValue = random.randint(1, 52)
        if randomCardValue <= 16:
            # Special Card
            suitValue = random.randint(1, len(self.suitDic))
            suit = self.suitDic[suitValue - 1]

            specialCard = random.choice(list(self.cardDic.items()))

            return {
                "suit": suit,
                "number": specialCard[0],
                "value": specialCard[1]
            }
        else:
            # Normal Card
            suitValue = random.randint(1, len(self.suitDic))
            suit = self.suitDic[suitValue - 1]

            numberValue = random.randint(2, 10)
            return {"suit": suit, "number": numberValue, "value": numberValue}

    def UserInput(self, choice):
        # Get user Input
        # Return "Hit" or "Stand"
        return choice

    def UserMessage(self, question):
        # For General Questions
        choice = input(question)
        return int(choice)

    def CalculateTotalValue(self, cards):
        total = 0

        for card in cards:
            total += card["value"]

        return total

    def DealerMove(self, value):
        if value < 17:
            return "Hit"
        else:
            return "Stand"

    def MakeMove(self, command):
        if command == "Hit":
            return controlCommands().GenerateCard()
        else:
            return {}

    def CalculateWinner(self, dealer, user):
        commands = controlCommands()

        dealerTotal = commands.CalculateTotalValue(dealer)
        userTotal = commands.CalculateTotalValue(user)

        print("Dealer:", dealerTotal)
        print("User:", userTotal)

        if dealerTotal > 21 and userTotal > 21:
            return "Nobody", "Both Bust"

        if dealerTotal > 21:
            return "User", "DealerBust"

        if userTotal > 21:
            return "Dealer", "UserBust"

        if dealerTotal == 21:
            return "Dealer", "21"

        if userTotal == 21:
            return "User", "21"

        if dealerTotal > userTotal:
            return "Dealer", "More"
        elif userTotal > dealerTotal:
            return "User", "More"

        if dealerTotal == userTotal:
            return "Nobody", "Tie"


def main():
    commands = controlCommands()

    dealer = [commands.GenerateCard(), commands.GenerateCard()]
    user = [commands.GenerateCard(), commands.GenerateCard()]

    print(commands.CalculateTotalValue(user))

    # Game
    while commands.CalculateTotalValue(
            dealer) < 21 and commands.CalculateTotalValue(user) < 21:
        userMove = commands.UserInput()

        dealerTotal = commands.CalculateTotalValue(dealer)
        dealerMove = commands.DealerMove(dealerTotal)

        if userMove == "Hit":
            card = commands.MakeMove(userMove)
            if card["number"] == "A":
                choice = commands.UserMessage(
                    "Would you like your 'Ace' to be: 1 / 11 ?: ")
                card["value"] = choice

            user.append(card)
            print(commands.CalculateTotalValue(user))

        if dealerMove == "Hit":
            card = commands.MakeMove(dealerMove)
            if card["number"] == "A":
                if dealerTotal + 11 < 21:
                    card["value"] = 11
                else:
                    card["value"] = 1

            dealer.append(card)

        if userMove == "Stand":
            break

    while commands.CalculateTotalValue(dealer) < 21:

        dealerTotal = commands.CalculateTotalValue(dealer)
        dealerMove = commands.DealerMove(dealerTotal)

        if dealerMove == "Hit":
            card = commands.MakeMove(dealerMove)
            if card["number"] == "A":
                if dealerTotal + 11 < 21:
                    card["value"] = 11
                else:
                    card["value"] = 1

        if dealerMove == "Stand":
            break

    print(commands.CalculateWinner(dealer, user))
