import sqlite3


def connect():
    global conn, curs
    # connect to data base DB
    conn = sqlite3.connect("./DATA/DB.db")
    curs = conn.cursor()
    # if table "accounts" does not exist, create it
    curs.execute(
        """CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, cash INTEGER, bank INTEGER, user_id INTEGER, loan INT, playing BOOL, inventory TEXT)"""
    )


def create_user(user_id):
    connect()
    # if user does not exist, create it
    if not curs.execute(
        "SELECT * FROM accounts WHERE user_id = ?", (user_id,)
    ).fetchone():
        curs.execute(
            "INSERT INTO accounts (cash, bank, user_id, loan, playing, inventory) VALUES (?, ?, ?, ?, ?, ?)",
            (1000, 0, user_id, False, False, ""),
        )
        conn.commit()


def update_balance(user_id, cash, bank):
    connect()
    curs.execute(
        "UPDATE accounts SET cash = ?, bank = ? WHERE user_id = ?",
        (cash, bank, user_id),
    )
    conn.commit()


def get_user(user_id):
    connect()
    # get user
    return curs.execute(
        "SELECT * FROM accounts WHERE user_id = ?", (user_id,)
    ).fetchone()


def update_user(user_id, cash, bank, inventory):
    connect()
    # update user
    curs.execute(
        "UPDATE accounts SET cash = ?, bank = ?, inventory = ? WHERE user_id = ?",
        (cash, bank, inventory, user_id),
    )
    conn.commit()


def delete_user(user_id):
    connect()
    # delete user
    curs.execute("DELETE FROM accounts WHERE user_id = ?", (user_id,))
    conn.commit()


def get_balance(user_id):
    connect()
    # get user
    return curs.execute(
        "SELECT cash, bank FROM accounts WHERE user_id = ?", (user_id,)
    ).fetchone()


def update_loan(user_id, value):
    connect()
    curs.execute("UPDATE accounts SET loan = ? WHERE user_id = ?",
                 (value, user_id))
    conn.commit()


def get_loan(user_id):
    connect()
    return curs.execute(
        "SELECT loan FROM accounts WHERE user_id = ?", (user_id,)
    ).fetchone()[0]
