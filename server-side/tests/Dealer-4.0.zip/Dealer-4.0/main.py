from discord import Embed, Guild, app_commands
import discord
from discord.ext import commands
from discord import app_commands
from discord.ext.commands import has_permissions, MissingPermissions
from typing import Optional, Literal
import os
# https://discord.com/api/oauth2/authorize?client_id=882669850944765983&permissions=2147502144&scope=bot%20applications.commands
# OTk1Mzc3OTI0Njc5MTQ3NjEw.GeL4GL.DXVKtzSkP3QpFJyQde45OzL7MOIjpjcevHnWaU


class MyBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="¬",
            intents=discord.Intents.default(),
        )

    async def setup_hook(self) -> None:
        print()
        for file in os.listdir("./cogs"):
            if file.endswith(".py"):
                name = file[:-3]
                await self.load_extension(f"cogs.{name}")
                print("\033[32m", "[+] Loaded cog: " + name)
        await bot.tree.sync()
        print()

    async def on_ready(self):
        await self.wait_until_ready()
        print()
        print("\033[32m", "[+] Client logged in as: " + self.user.name)
        print("\033[32m",
              "[+] Client is in " + str(len(self.guilds)) + " servers")
        print()
        for guild in self.guilds:
            print("\033[32m", "[+] Client is in " + guild.name)
        


bot = MyBot()


# A command to call the reload
@bot.command()
async def reload(ctx: commands.Context):
    if ctx.author.id == 632519262585618437 or ctx.author.id == 504216041463873537:
        for file in os.listdir("./cogs"):
            if file.endswith(".py"):
                await bot.reload_extension(f"cogs.{file[:-3]}")
                print("\033[91m", "[-] Reloaded cog: " + file[:-3])
        # Syncs the new Cog class with the Discord API.
        print()
        print("\033[32m", "[+] Sync Cogs with Discord API")
        await bot.tree.sync()
        await ctx.send("Reloaded Cog")
    else:
        pass


@bot.command()
async def rules(ctx: commands.Context):
    if ctx.author.id == 632519262585618437 or ctx.author.id == 504216041463873537:
        embed = Embed(
            title=f"<:TheDealerCircle:1079036931515621386> **The Dealer Games: Rules**",
            description=f"<@882669850944765983> was created by <@504216041463873537> and developed with <@632519262585618437>. If you require any support, please message on the of the admins.\n\n1. **Respect**\nTreat everyone with respect. Absolutely no harassment, sexism, racism or hate speech will be tolerated.\n\n2. **Inform**\nIf you see something against the rules or something that makes you feel unsafe, let staff know. We want this server to be a welcoming space!\n\n3. **Spam**\nNo spam or self-promotion (server invites, advertisements etc) without permission from a staff member. This includes DMing fellow members.\n\n4. **NSFW Content**\nNo age-restricted or obscene content. This includes text, images or links featuring nudity, sex, hard violence or other disturbing graphic content.\n\n5. **Context**\nRemain on topic and use channels correctly.\n\n6. **Links**\nNo Discord server invite links or codes.\n\n7. **Have fun!**",
            color=0xFFFF00
        )
        embed.set_footer(text="Posted by Tommy.")
        channel_id = 891369200864624741
        # Getting the channel
        channel = bot.get_channel(channel_id)
        print(channel.name)
        await channel.send(embed=embed)


@bot.command()
async def sync(ctx: commands.Context,
               guilds: commands.Greedy[discord.Object] = None) -> None:
    if ctx.author.id == 632519262585618437:
        if not guilds:
            print()
            synced = await ctx.bot.tree.sync(guild=ctx.guild)
            print("\033[32m", "[+] Synced " + str(synced) + " guilds")

            await ctx.send(f"Synced {len(synced)} commands globally")
            return

        ret = 0
        for guild in guilds:
            try:
                await ctx.bot.tree.sync(guild=guild)
            except discord.HTTPException:
                pass
            else:
                ret += 1

        await ctx.send(f"Synced the tree to {ret}/{len(guilds)}.")
    else:
        pass


bot.run(
    "ODgyNjY5ODUwOTQ0NzY1OTgz.G9oU4B.aIILA7x6m685IB3jweF6n6nBDFaRHi1GQtIG4k")
